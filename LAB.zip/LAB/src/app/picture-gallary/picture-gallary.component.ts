import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-picture-gallary',
  templateUrl: './picture-gallary.component.html',
  styleUrls: ['./picture-gallary.component.css']
})
export class PictureGallaryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
