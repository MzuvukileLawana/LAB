export interface ContactMe {
  id: number;
  fullName: string;
  emailAddress: string;
  contactNumber: number;
  digitalOrTrans: string
  }
  