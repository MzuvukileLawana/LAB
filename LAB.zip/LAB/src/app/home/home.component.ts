import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import {ContactMe} from '../shared/models/contact-me/contact-me.model';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  contactMeForm: FormGroup;
  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.contactMeForm = this.formBuilder.group({
      fullName: ['',Validators.required],
      emailAddress: ['', [Validators.required,Validators.email]],
      contactNumber: ['', Validators.compose([Validators.required,
        Validators.pattern('^[0-9]{10}$'), Validators.maxLength(10)])],
      digitalOrTrans: ['', Validators.required]
    });
  }

  get formControls() {
    return this.contactMeForm.controls;
  }
  onSubmit(){
    if (this.contactMeForm.valid){
      this.saveContactForm();
    }
  }
  saveContactForm() {
    let contactMe: ContactMe = {
      id: 0,
      fullName : this.formControls.fullName.value,
      emailAddress : this.formControls.emailAddress.value,
      contactNumber : this.formControls.contactNumber.value,
      digitalOrTrans : this.formControls.digitalOrTrans.value
    }
  debugger;
    
      console.log(contactMe);
     
  }


}
